<?php
/**
 * User preferences form
 */

declare(strict_types=1);

namespace PhpMyAdmin\Config\Forms\Page;

class ExportForm extends \PhpMyAdmin\Config\Forms\User\ExportForm
{
}
